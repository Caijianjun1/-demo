var MD5 = require('../../utils/md5.js')
Page({
  data: {
    image: "",
    access_token: "",
    tempFilePaths: "",
    final_dict:{}
  },

  load_image() {
    var FSM = wx.getFileSystemManager();
    var image = this.data.image;
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        var tempFiles_size = res.tempFiles[0].size;
        console.log(tempFilePaths)
        console.log(tempFiles_size)
        if (tempFiles_size > 4096 * 1024) {
          wx.showToast({
            title: '图片过大',
            icon: 'none',
            mask: true,
            duration: 2000
          })
        }
        else {
          wx.showToast({
            title: '很快就好了呢',
            icon: 'none',
            mask: true,
            duration: 2000
          })
          that.setData({
            tempFilePaths: tempFilePaths
          })
          FSM.readFile({
            filePath: res.tempFilePaths[0],
            encoding: "base64",
            success: function (data) {
              image = data.data
              that.setData({
                image: image
              })
            }
          })
          that.win_accession_token()
        }
      }
    })
  },


  win_accession_token() {
    var that = this;
    var access_token = this.data.access_token;
    wx.request({
      url: 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=nU2l3GROq6h19egMLsriZWiK&client_secret=zZZp362I2s8KUt5vSgnEH7yT0atpCo0L',
      success(res) {
        access_token = res.data['access_token']
        that.setData({
          access_token: access_token
        })
        console.log(access_token)
        that.win_text()
      }
    })
  },
  win_text() {
    var that = this;
    var final_dict = this.data.final_dict;
    var image = this.data.image;
    var access_token = this.data.access_token;
    wx.request({
      url: 'https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general',
      data: {
        access_token: access_token,
        image: this.data.image
      },
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      method: 'POST',
      success(res) {
        console.log(res.data)
        for (var i = 0; i < res.data.result.length; i++) {
          var q = res.data.result[i]['keyword']
          console.log(q)
          // final_dict[q] = 
          that.translate(q)
        }
        console.log(final_dict)
        that.setData({
          final_dict: final_dict
        })
        wx.showToast({
          title: '识别成功',
          icon: 'none',
          mask: true,
          duration: 1500
        })
      }
    })
  },

  translate:function(q){
    var appid = '20190205000263097';
    var appserect = 'v_zXxFPUnLRCI2lQXFvB'
    var salt = (new Date).getTime();
    var sign = MD5.md5(appid + q +salt +appserect);
    console.log(MD5.md5(q))
    wx.request({
      url: 'https://fanyi-api.baidu.com/api/trans/vip/translate',
      data:{
        'q':q,
        'from':'auto',
        'to':'en',
        'appid':appid,
        'salt': salt,
        'sign': sign,
      },
      success(data){
        console.log(data.data['trans_result'])
      }
    })

  },

  onLoad: function (options) {


  },
  /**
   \* 生命周期函数--监听页面显示
   */
  onShow: function () {

  },


  /**
   \* 生命周期函数--监听页面隐藏
   */
  onHide: function () {


  },


  /**
   \* 生命周期函数--监听页面卸载
   */
  onUnload: function () {


  },


  /**
   \* 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {


  },


  /**
   \* 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {


  },


  /**
   \* 用户点击右上角分享
   */
  onShareAppMessage: function () {


  }
})

