﻿
Page({

  /**
   * 页面的初始数据
   */
  data: {
    image: "",
    access_token: "",
    tempFilePaths: "",
    final_text: ""
  },

  copy: function (e) {
    var that = this;
    wx.setClipboardData({
      //去找上面的数据
      data: that.data.final_text,
      success: function (res) {
        wx.showToast({
          title: '复制成功',
        });
      }
    });
  },
  load_image() {
    var FSM = wx.getFileSystemManager();
    var image = this.data.image;
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        var tempFiles_size = res.tempFiles[0].size;
        console.log(tempFilePaths)
        console.log(tempFiles_size)
        if (tempFiles_size > 4096 * 1024) {
          wx.showToast({
            title: '图片过大了呢',
            icon: 'none',
            mask: true,
            duration: 2000
          })
        }
        else {
          wx.showToast({
            title: '很快就好了呢',
            icon: 'none',
            mask: true,
            duration: 2000
          })
          that.setData({
            tempFilePaths: tempFilePaths
          })
          FSM.readFile({
            filePath: res.tempFilePaths[0],
            encoding: "base64",
            success: function (data) {
              image = data.data
              that.setData({
                image: image
              })
            }
          })
          that.win_access_token()
        }
      }
    })
  },

  win_access_token() {
    var that = this;
    var access_token = this.data.access_token;
    wx.request({
      url: '百度Ai开发平台url',
      success(res) {
        access_token = res.data['access_token']
        that.setData({
          access_token: access_token
        })
        console.log(access_token)
        that.win_text()
      }
    })
  },
  win_text() {
    var that = this;
    var final_text = this.data.final_text;
    var image = this.data.image;
    var access_token = this.data.access_token;
    wx.request({
      url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic',
      data: {
        access_token: access_token,
        image: this.data.image
      },
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      method: 'POST',
      success(res) {
        console.log(res.data)
        for (var i = 0; i < res.data.words_result.length; i++) {
          final_text += res.data.words_result[i]['words']
        }
        console.log(final_text)
        that.setData({
          final_text: final_text
        })
        wx.showToast({
          title: '好啦，快来使用一键复制',
          icon: 'none',
          mask: true,
          duration: 1500
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      final_text: ""
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})